﻿var GenderMaster = [{ "Text": "Male" }, { "Text": "FeMale" }, { "Text": "Others"}];

var HobbyList = [{ "name": "drawing" }, { "name": "singing" }, { "name": "painting"}];
